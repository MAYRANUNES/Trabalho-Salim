/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author MÁYRA NUNES
 */
public class Principal {
    public static void main(String[] args) {
      
                //inserção de 1 Gênero no SGBD
                Genero_Musical g1 = new Genero_Musical("Rock");
		if(Conexao.inserirgenero(g1)!=0) {
                    System.out.println("Gênero inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
                    
		}
                // inserção de um Artista;
                Artista a = new Artista("Oficina G3");
                
		if(Conexao.inserirArtista(a)!=0) {
                    System.out.println("Artista inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                // inserção de um album
                Album b1 = new Album ("Depois da guerra", 2010);
                
		if(Conexao.inseriralbum(b1)!=0) {
                    System.out.println("Album inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção do Album!");
		}
                
		// inserção de outra Musica no SGBD
		
		Musica y = new Musica("Incondicional", 300, 10);
               
		if(Conexao.inserirmusica(y)!=0) {
                    System.out.println("Musica inserida com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                
                //inserção de 1 Gênero no SGBD
                Genero_Musical g2 = new Genero_Musical("Gospel");
		if(Conexao.inserirgenero(g2)!=0) {
                    System.out.println("Gênero inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
                    
		}
                // inserção de um Artista;
                Artista a1 = new Artista("Aline Barros");
                
		if(Conexao.inserirArtista(a1)!=0) {
                    System.out.println("Artista inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                // inserção de um album
                Album b2 = new Album ("Graça", 2013);
		if(Conexao.inseriralbum(b1)!=0) {
                    System.out.println("Album inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção do Album!");
		}
                
		// inserção de outra Musica no SGBD
		Musica y1 = new Musica("Lugar Seguro", 300, 10);
               
		if(Conexao.inserirmusica(y1)!=0) {
                    System.out.println("Musica inserida com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                
		//Exemplo de atualização da Musica no SGBD, buscando-a pelo nome atual!!!
		
		y.setNota(10);
		String nome = y.getNomemusica();
		y.setNomemusica("Tua Palavra");
		if(Conexao.atualizar(y, nome)!=0) {
                   
			System.out.println("Música atualizada com sucesso no banco!");
		} else {
			System.out.println("Erro na atualização!");
		}
		
		//Exemplo de listagem de todas Musicas do SGBD
	
		ResultSet res = Conexao.relatorioCompleto();
		if(res!=null) {
			try {
                            while(res.next()) {
                                
				System.out.println("....Musica: "+res.getString("musica.nome"));
				System.out.println("...Artista: "+res.getString("artista.nome"));
				System.out.println(".....Album: "+res.getString("album.nome"));
                                System.out.println("....Genero: "+res.getString("genero.nome"));
				System.out.println("==========");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }
              
        // LISTAGEM DE TODOS OS ALBUNS DO BANCO
                ResultSet resal = Conexao.relatorioalbum();
		if(resal!=null) {
			try {
                            while(resal.next()) {
                                System.out.println("Album: ");
                                System.out.println("........Id: "+resal.getInt("id"));
				System.out.println("......Nome: "+resal.getString("nome"));
				System.out.println("...Artista: "+resal.getInt("artista_id"));
				System.out.println(".......Ano: "+resal.getInt("ano"));
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx\n");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }
                
                
                // LISTAGEM DE TODOS OS ARTISTAS;
                ResultSet resart = Conexao.relatorioArtista();
		if(resart!=null) {
			try {
                            while(resart.next()) {
                                System.out.println("\nArtista:");
                                System.out.println("........Id: "+resart.getInt("id"));
				System.out.println("......Nome: "+resart.getString("nome"));
				System.out.println("...Genero Id: "+resart.getInt("genero_id"));
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }   
                
                // relatorio de todos os generos
                ResultSet resge = Conexao.relatorioGenero();
		if(resge!=null) {
			try {
                            while(resge.next()) {
                                System.out.println("\nGenero:");
                                System.out.println("........Id: "+resge.getInt("id"));
				System.out.println("......Nome: "+resge.getString("nome"));
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }      
		        
	}
}
