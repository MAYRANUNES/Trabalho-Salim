/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author MÁYRA NUNES
 */
public class Conexao {
    
    //Método para Conectar ao Banco de Dados Local chamado 'bibliotecamusical', usuário 'root' e senha em branco!
	public static Connection conectar() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://127.0.0.1/bibliotecamusical", "root", "");
			return(c);
		} catch (ClassNotFoundException e) {
			System.out.println("Problema na configuração do Driver do MySQL!");
                        
		} catch (SQLException e) {
			System.out.println("Problema na conexão com o banco de dados!");
		}
		return(null);
	}
	
        //Método inserir no banco um Genero Musical;
	public static int inserirgenero(Genero_Musical g) {
		String insercao = "INSERT INTO genero (nome) VALUES ('"+g.getNomeGenero()+"');";
		Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeUpdate(insercao));
		} catch (SQLException e) {
                    System.out.println("Problema na inserção do Gênero no banco!");
		}
		return(0);
	}
        
        public static int inseriralbum(Album a) {
		String insercao = "INSERT INTO album (nome, ano, artista_id)  VALUES ('"+a.getNomeAlbum()+"',"+a.getAnoLancamento()+",1);";
                Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeUpdate(insercao));
		} catch (SQLException e) {
                    System.out.println("Problema na inserção do Album no banco!");
		}
		return(0);
	}
        
        public static int inserirArtista(Artista m) {
		String insercao = "INSERT INTO artista (nome,genero_id) VALUES ('"+m.getNomeArtista()+"',1);";
                Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeUpdate(insercao));
		} catch (SQLException e) {
                    System.out.println("Problema na inserção do Artista no banco!");
		}
		return(0);
	}
 	
	//Método para inserir no banco uma Música passada como parâmetro
	public static int inserirmusica(Musica p) {
		String insercao = "INSERT INTO musica (nome, nota, duracao,album_id) VALUES ('"+p.getNomemusica()+"',"+p.getNota()+",'"+p.getTempo()+"',1);";
                Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeUpdate(insercao));
		} catch (SQLException e) {
                    System.out.println("Problema na inserção da Musica!");
		}
		return(0);
	}
    
            //Listar Albuns
            public static ResultSet relatorioalbum() {
		Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeQuery("select * from album;"));
		} catch (SQLException e) {
                    System.out.println("Problema na consulta!");
		}
		return(null);
            }
            
            // Listar Todos os generos
            public static ResultSet relatorioGenero() {
		Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeQuery("select * from genero;"));
		} catch (SQLException e) {
                    System.out.println("Problema na consulta!");
		}
		return(null);
            }
            
            //Listar Artistas
            public static ResultSet relatorioartista() {
                    Connection con = conectar();
                    Statement st;
                    try {
                        st = con.createStatement();
                        return(st.executeQuery("select * from artista;"));
                    } catch (SQLException e) {
                        System.out.println("Problema na consulta!");
                    }
                    return(null);
            }
        //Relatório contendo todas as Músicas do Banco
	public static ResultSet relatorioCompleto() {
		Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeQuery(" select musica.nome,artista.nome,album.nome,genero.nome from musica, artista,album,genero where musica.album_id = album.id and album.artista_id = artista.id and artista.genero_id = genero.id;;"));
		} catch (SQLException e) {
                    System.out.println("Problema na consulta Geral!");
		}
		return(null);
	}
        //Relatório contendo todas os artistas
	public static ResultSet relatorioArtista() {
		Connection con = conectar();
		Statement st;
		try {
                    st = con.createStatement();
                    return(st.executeQuery("select * from artista;"));
		} catch (SQLException e) {
                    System.out.println("Problema na consulta!");
		}
		return(null);
	}
       //PESQUISA NOME ALBUM
        public static ResultSet pesqAlbum(String nome) {
                Connection con = conectar();
                Statement st;
                try {
                        st = con.createStatement();
                return(st.executeQuery("SELECT id,nome,ano FROM album where nome = '"+nome+"';"));
                } catch (SQLException e) {
                        System.out.println("Problema na consulta!");
                }
                return(null);
        }
        
        //PESQUISA NOME ARTISTA
        public static ResultSet pesqArtista(String nome) {
                Connection con = conectar();
                Statement st;
                try {
                        st = con.createStatement();
                return(st.executeQuery("SELECT id,nome,genero_id FROM artista where nome = '"+nome+"';"));
                } catch (SQLException e) {
                        System.out.println("Problema na consulta!!");
                }
                return(null);
        }
        
        // PESQUISA NOME MUSICA
        public static ResultSet pesqMusica(String nome) {
                Connection con = conectar();
                Statement st;
                try {
                        st = con.createStatement();
                return(st.executeQuery("SELECT * from musica where nome = '"+nome+"';"));
                } catch (SQLException e) {
                        System.out.println("Problema na consulta!");
                }
                return(null);
        }
        
        //PESQUISA NOME GENERO
        public static ResultSet pesqGenero(String nome) {
                Connection con = conectar();
                Statement st;
                try {
                        st = con.createStatement();
                return(st.executeQuery("SELECT id, nome from genero where nome = '"+nome+"';"));
                } catch (SQLException e) {
                        System.out.println("Problema na consulta !");
                }
                return(null);
        }
        
	//Método para Atualizar os campos no banco uma Musica passada como parâmetro, buscando-a pelo nome atual!!!
            public static int atualizar(Musica p, String n) {
		String atualizacao = "UPDATE musica SET nome = '"+p.getNomemusica()+"', nota = "+p.getNota()+", duracao = '"+p.getTempo()+"' WHERE nome = '"+n+"';";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(atualizacao));
		} catch (SQLException e) {
			System.out.println("Problema na atualização da Musica!");
		}
		return(0);
            }
    
}
