/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

/**
 *
 * @author MÁYRA NUNES
 */
public class Musica {
    
    private String nomemusica;
    private float tempo;
    private int nota;
    private int album_id;

    public Musica(String nomemusica, float tempo, int nota) {
        this.nomemusica = nomemusica;
        this.tempo = tempo;
        this.nota = nota;
        
    }

    public int getAlbum_id() {
        return album_id;
    }

    public void setAlbum_id(int album_id) {
        this.album_id = album_id;
    }
   
    public String getNomemusica() {
        return nomemusica;
    }

    public void setNomemusica(String nomemusica) {
        this.nomemusica = nomemusica;
    }

    public float getTempo() {
        return tempo;
    }

    public void setTempo(float tempo) {
        this.tempo = tempo;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
    
    public void exibeMusica(){
        System.out.println("..............Musica: "+nomemusica);
        System.out.println(".......Tempo Duração: "+tempo);
        System.out.println("Nota Classificatória: "+nota);
        
    }
    
}
